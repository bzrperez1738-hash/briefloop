const css = `
  @import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500&display=swap');
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --bg:#0e0f0d; --bg2:#161714; --border:rgba(255,255,255,0.07);
    --text:#e8e6df; --muted:#7a7870; --teal:#1D9E75;
    --serif:'DM Serif Display',Georgia,serif; --sans:'DM Sans',system-ui,sans-serif;
  }
  html, body { background:var(--bg); color:var(--text); font-family:var(--sans); }
  .nav {
    display:flex; align-items:center; justify-content:space-between;
    padding:0 3rem; height:60px; border-bottom:1px solid var(--border);
    background:var(--bg);
  }
  .nav-logo { font-family:var(--serif); font-size:20px; cursor:pointer; }
  .nav-logo em { color:var(--teal); font-style:normal; }
  .doc { max-width:720px; margin:0 auto; padding:4rem 2rem 6rem; }
  .doc-title { font-family:var(--serif); font-size:42px; letter-spacing:-.5px; margin-bottom:.5rem; }
  .doc-date { font-size:13px; color:var(--muted); margin-bottom:3rem; padding-bottom:2rem; border-bottom:1px solid var(--border); }
  .doc h2 { font-family:var(--serif); font-size:22px; margin:2.5rem 0 .75rem; }
  .doc p { font-size:14px; color:var(--muted); line-height:1.8; margin-bottom:1rem; }
  .doc ul { padding-left:1.5rem; margin-bottom:1rem; }
  .doc ul li { font-size:14px; color:var(--muted); line-height:1.8; margin-bottom:.4rem; }
  .doc a { color:var(--teal); }
`;

export default function Privacy({ onHome }) {
  return (
    <>
      <style>{css}</style>
      <nav className="nav">
        <div className="nav-logo" onClick={onHome}>Brief<em>Loop</em></div>
      </nav>
      <div className="doc">
        <div className="doc-title">Privacy Policy</div>
        <div className="doc-date">Last updated: June 2026</div>

        <h2>1. Information We Collect</h2>
        <p>We collect information you provide directly to us, including:</p>
        <ul>
          <li>Account information (email address and password) when you create an account</li>
          <li>Meeting transcripts and notes you submit for processing</li>
          <li>Payment information processed securely through Stripe (we never store card details)</li>
          <li>Usage data such as number of meetings processed and features used</li>
        </ul>

        <h2>2. How We Use Your Information</h2>
        <p>We use the information we collect to:</p>
        <ul>
          <li>Provide, maintain, and improve BriefLoop's services</li>
          <li>Process your meeting transcripts using AI to generate summaries and action items</li>
          <li>Send you transactional emails such as account confirmations and receipts</li>
          <li>Respond to your comments, questions, and requests</li>
          <li>Monitor and analyze usage patterns to improve user experience</li>
        </ul>

        <h2>3. Meeting Transcript Data</h2>
        <p>Your meeting transcripts are processed by our AI to generate summaries and action items. We treat your transcript data as confidential. We do not sell, share, or use your transcript content to train AI models without your explicit consent. Transcripts are stored securely in your account and are only accessible by you.</p>

        <h2>4. Data Sharing</h2>
        <p>We do not sell your personal information. We may share your information with:</p>
        <ul>
          <li><strong>Anthropic</strong> — to process meeting transcripts via their AI API (subject to Anthropic's privacy policy)</li>
          <li><strong>Supabase</strong> — for secure database storage and authentication</li>
          <li><strong>Stripe</strong> — for payment processing</li>
          <li><strong>Vercel</strong> — for application hosting</li>
        </ul>

        <h2>5. Data Retention</h2>
        <p>We retain your account data and meeting history for as long as your account is active. You may delete your account and all associated data at any time by contacting us at privacy@briefloop.io. We will delete your data within 30 days of your request.</p>

        <h2>6. Security</h2>
        <p>We take reasonable measures to protect your information from unauthorized access, theft, and loss. All data is encrypted in transit using HTTPS and encrypted at rest in our database. However, no security system is impenetrable and we cannot guarantee absolute security.</p>

        <h2>7. Cookies</h2>
        <p>We use essential cookies to keep you logged in and maintain your session. We do not use tracking cookies or advertising cookies.</p>

        <h2>8. Your Rights</h2>
        <p>You have the right to access, update, or delete your personal information at any time. You may also request a copy of all data we hold about you. To exercise these rights, contact us at privacy@briefloop.io.</p>

        <h2>9. Children's Privacy</h2>
        <p>BriefLoop is not intended for children under 13 years of age. We do not knowingly collect personal information from children under 13.</p>

        <h2>10. Changes to This Policy</h2>
        <p>We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new policy on this page and updating the "Last updated" date.</p>

        <h2>11. Contact Us</h2>
        <p>If you have any questions about this Privacy Policy, please contact us at <a href="mailto:privacy@briefloop.io">privacy@briefloop.io</a>.</p>
      </div>
    </>
  );
}
