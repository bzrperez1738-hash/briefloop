const css = `
  @import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500&display=swap');
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --bg:#0e0f0d; --bg2:#161714; --border:rgba(255,255,255,0.07);
    --text:#e8e6df; --muted:#7a7870; --teal:#1D9E75;
    --serif:'DM Serif Display',Georgia,serif; --sans:'DM Sans',system-ui,sans-serif;
  }
  html, body { background:var(--bg); color:var(--text); font-family:var(--sans); }
  .nav {
    display:flex; align-items:center; justify-content:space-between;
    padding:0 3rem; height:60px; border-bottom:1px solid var(--border);
    background:var(--bg);
  }
  .nav-logo { font-family:var(--serif); font-size:20px; cursor:pointer; }
  .nav-logo em { color:var(--teal); font-style:normal; }
  .doc { max-width:720px; margin:0 auto; padding:4rem 2rem 6rem; }
  .doc-title { font-family:var(--serif); font-size:42px; letter-spacing:-.5px; margin-bottom:.5rem; }
  .doc-date { font-size:13px; color:var(--muted); margin-bottom:3rem; padding-bottom:2rem; border-bottom:1px solid var(--border); }
  .doc h2 { font-family:var(--serif); font-size:22px; margin:2.5rem 0 .75rem; }
  .doc p { font-size:14px; color:var(--muted); line-height:1.8; margin-bottom:1rem; }
  .doc ul { padding-left:1.5rem; margin-bottom:1rem; }
  .doc ul li { font-size:14px; color:var(--muted); line-height:1.8; margin-bottom:.4rem; }
  .doc a { color:var(--teal); }
`;

export default function Terms({ onHome }) {
  return (
    <>
      <style>{css}</style>
      <nav className="nav">
        <div className="nav-logo" onClick={onHome}>Brief<em>Loop</em></div>
      </nav>
      <div className="doc">
        <div className="doc-title">Terms of Service</div>
        <div className="doc-date">Last updated: June 2026</div>

        <h2>1. Acceptance of Terms</h2>
        <p>By accessing or using BriefLoop ("the Service"), you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use the Service.</p>

        <h2>2. Description of Service</h2>
        <p>BriefLoop is an AI-powered tool that processes meeting transcripts to generate summaries, action items, and follow-up email drafts. The Service is provided on a subscription basis with plans as described on our pricing page.</p>

        <h2>3. Account Registration</h2>
        <p>You must create an account to use BriefLoop. You are responsible for:</p>
        <ul>
          <li>Maintaining the confidentiality of your account credentials</li>
          <li>All activity that occurs under your account</li>
          <li>Providing accurate and complete registration information</li>
          <li>Notifying us immediately of any unauthorized use of your account</li>
        </ul>

        <h2>4. Subscription and Payment</h2>
        <p>BriefLoop offers paid subscription plans billed monthly. By subscribing you agree to pay the applicable fees. Subscriptions automatically renew unless cancelled before the renewal date. Payments are processed securely by Stripe. We do not store your payment card information.</p>

        <h2>5. Free Trial</h2>
        <p>New users receive 10 free meeting credits upon registration. No credit card is required to start. Free trial credits do not roll over or expire but are limited to one per account.</p>

        <h2>6. Cancellation and Refunds</h2>
        <p>You may cancel your subscription at any time from your account settings. Cancellation takes effect at the end of the current billing period. We offer a 14-day money-back guarantee for first-time subscribers. Refund requests after 14 days are evaluated on a case-by-case basis.</p>

        <h2>7. Acceptable Use</h2>
        <p>You agree not to use BriefLoop to:</p>
        <ul>
          <li>Process transcripts containing illegal content</li>
          <li>Violate any applicable laws or regulations</li>
          <li>Infringe on the intellectual property rights of others</li>
          <li>Attempt to reverse engineer or copy the Service</li>
          <li>Use the Service for any purpose other than processing your own meeting content</li>
        </ul>

        <h2>8. Your Content</h2>
        <p>You retain ownership of all meeting transcripts and content you submit. By using the Service, you grant BriefLoop a limited license to process your content solely for the purpose of providing the Service to you. We do not claim ownership of your content.</p>

        <h2>9. AI-Generated Content</h2>
        <p>BriefLoop uses AI to generate summaries, action items, and email drafts. AI-generated content may contain errors or inaccuracies. You are responsible for reviewing and verifying all AI-generated content before acting on it or sharing it.</p>

        <h2>10. Limitation of Liability</h2>
        <p>BriefLoop is provided "as is" without warranties of any kind. To the maximum extent permitted by law, BriefLoop shall not be liable for any indirect, incidental, special, or consequential damages arising from your use of the Service, including any errors in AI-generated summaries or action items.</p>

        <h2>11. Changes to Terms</h2>
        <p>We may update these Terms from time to time. We will notify you of significant changes by email. Continued use of the Service after changes constitutes acceptance of the new terms.</p>

        <h2>12. Governing Law</h2>
        <p>These Terms are governed by the laws of the State of California, United States, without regard to conflict of law principles.</p>

        <h2>13. Contact</h2>
        <p>For questions about these Terms, contact us at <a href="mailto:legal@briefloop.io">legal@briefloop.io</a>.</p>
      </div>
    </>
  );
}
